(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 375:
/***/ ((module) => {

// Exports
module.exports = {
	"avatar": "Avatar_avatar__3eVBj"
};


/***/ }),

/***/ 347:
/***/ ((module) => {

// Exports
module.exports = {
	"page": "PageWrapper_page__Xo3lf",
	"ukraine": "PageWrapper_ukraine__WcwJ4",
	"content": "PageWrapper_content__sDRQX"
};


/***/ }),

/***/ 854:
/***/ ((module) => {

// Exports
module.exports = {
	"social": "SocialButton_social__8uZFy"
};


/***/ }),

/***/ 274:
/***/ ((module) => {

// Exports
module.exports = {
	"title": "Title_title__E_1_z",
	"red": "Title_red__3_A6f",
	"white": "Title_white__QkQgw",
	"grey": "Title_grey__X1ZIc"
};


/***/ }),

/***/ 156:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Home_container__zBkib",
	"label": "Home_label__Fh8Cf",
	"socials": "Home_socials__lfAQK"
};


/***/ }),

/***/ 681:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./styles/Home.module.sass
var Home_module = __webpack_require__(156);
var Home_module_default = /*#__PURE__*/__webpack_require__.n(Home_module);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(377);
// EXTERNAL MODULE: ./components/PageWrapper/PageWrapper.module.sass
var PageWrapper_module = __webpack_require__(347);
var PageWrapper_module_default = /*#__PURE__*/__webpack_require__.n(PageWrapper_module);
;// CONCATENATED MODULE: external "react-double-marquee"
const external_react_double_marquee_namespaceObject = require("react-double-marquee");
var external_react_double_marquee_default = /*#__PURE__*/__webpack_require__.n(external_react_double_marquee_namespaceObject);
;// CONCATENATED MODULE: ./components/PageWrapper/PageWrapper.js




const PageWrapper = ({ children  })=>{
    const { t  } = (0,external_next_i18next_.useTranslation)("common");
    const optionsMarquee = {
        "direction": "left",
        "speed": 0.04,
        "delay": 3000,
        "childMargin": 15,
        "scrollWhen": "always"
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (PageWrapper_module_default()).page,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (PageWrapper_module_default()).ukraine,
                children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_double_marquee_default()), {
                    direction: "left",
                    childMargin: 3,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        children: [
                            t("ukraineLong"),
                            " ",
                            t("ukraineLong"),
                            " ",
                            t("ukraineLong"),
                            " ",
                            t("ukraineLong"),
                            " ",
                            t("ukraineLong"),
                            " ",
                            t("ukraineLong")
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (PageWrapper_module_default()).header
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (PageWrapper_module_default()).content,
                children: children
            })
        ]
    });
};
/* harmony default export */ const PageWrapper_PageWrapper = (PageWrapper);

;// CONCATENATED MODULE: ./components/PageWrapper/index.js

/* harmony default export */ const components_PageWrapper = (PageWrapper_PageWrapper);

// EXTERNAL MODULE: ./components/Title/Title.module.sass
var Title_module = __webpack_require__(274);
var Title_module_default = /*#__PURE__*/__webpack_require__.n(Title_module);
;// CONCATENATED MODULE: ./components/Title/Title.js


const Title = ({ label ="" , color ="white" , unSplit =false , dotColor  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
        className: `${(Title_module_default()).title} ${(Title_module_default())[color]}`,
        children: [
            unSplit ? /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                children: label
            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                        children: label.split(" ")[0]
                    }),
                    label.split(" ").length > 1 && " ",
                    label.split(" ").slice(1).join(" ")
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                className: (Title_module_default())[dotColor],
                children: "."
            })
        ]
    })
;
/* harmony default export */ const Title_Title = (Title);

;// CONCATENATED MODULE: ./components/Title/index.js

/* harmony default export */ const components_Title = (Title_Title);

// EXTERNAL MODULE: ./components/Avatar/Avatar.module.sass
var Avatar_module = __webpack_require__(375);
var Avatar_module_default = /*#__PURE__*/__webpack_require__.n(Avatar_module);
;// CONCATENATED MODULE: ./components/Avatar/Avatar.js


const Avatar = ({ img ="/img/avatar.jpeg" , alt ="agcakza"  })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (Avatar_module_default()).avatar,
        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
            src: img,
            alt: alt
        })
    })
;
/* harmony default export */ const Avatar_Avatar = (Avatar);

;// CONCATENATED MODULE: ./components/Avatar/index.js

/* harmony default export */ const components_Avatar = (Avatar_Avatar);

// EXTERNAL MODULE: ./components/SocialButton/SocialButton.module.sass
var SocialButton_module = __webpack_require__(854);
var SocialButton_module_default = /*#__PURE__*/__webpack_require__.n(SocialButton_module);
;// CONCATENATED MODULE: ./components/SocialButton/SocialButton.js


const SocialButton = ({ src , alt , link  })=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
        href: link,
        target: "_blank",
        className: (SocialButton_module_default()).social,
        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
            src: src,
            alt: alt
        })
    })
;
/* harmony default export */ const SocialButton_SocialButton = (SocialButton);

;// CONCATENATED MODULE: ./components/SocialButton/index.js

/* harmony default export */ const components_SocialButton = (SocialButton_SocialButton);

;// CONCATENATED MODULE: ./components/index.js






;// CONCATENATED MODULE: external "next-i18next/serverSideTranslations"
const serverSideTranslations_namespaceObject = require("next-i18next/serverSideTranslations");
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
;// CONCATENATED MODULE: ./pages/index.js






const Home = ()=>{
    const { t  } = (0,external_next_i18next_.useTranslation)("common");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(components_PageWrapper, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("title", {
                    children: "Avtandil Katsadze"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Home_module_default()).container,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(components_Avatar, {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Home_module_default()).label,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(components_Title, {
                                unSplit: true,
                                label: "Developer",
                                color: "red",
                                dotColor: "red"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(components_Title, {
                                unSplit: true,
                                label: "Digitalpreneur",
                                color: "grey",
                                dotColor: "red"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(components_Title, {
                                unSplit: true,
                                label: "Stan",
                                color: "white",
                                dotColor: "red"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: t("hello")
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Home_module_default()).socials,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(components_SocialButton, {
                                src: "/img/instagram.svg",
                                link: "https://instagram.com/agcakza",
                                alt: "Instagram"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(components_SocialButton, {
                                src: "/img/linkedin.svg",
                                link: "https://www.linkedin.com/in/agcakza/",
                                alt: "LinkedIn"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(components_SocialButton, {
                                src: "/img/steam.svg",
                                link: "https://steamcommunity.com/id/agcakza",
                                alt: "Steam"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(components_SocialButton, {
                                src: "/img/telegram.svg",
                                link: "https://t.me/agcakza",
                                alt: "Telegram"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
const getStaticProps = async ({ locale  })=>({
        props: {
            ...await (0,serverSideTranslations_namespaceObject.serverSideTranslations)(locale, [
                "common"
            ])
        }
    })
;
/* harmony default export */ const pages = (Home);


/***/ }),

/***/ 377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(681));
module.exports = __webpack_exports__;

})();